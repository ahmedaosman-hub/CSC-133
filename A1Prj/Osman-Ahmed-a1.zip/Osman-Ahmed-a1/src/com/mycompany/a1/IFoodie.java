package com.mycompany.a1;

public interface IFoodie {
	public void setFoodConsumptionRate(int foodConsumptionRate);
	
}
