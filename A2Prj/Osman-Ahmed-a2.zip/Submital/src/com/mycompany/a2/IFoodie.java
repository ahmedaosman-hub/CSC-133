package com.mycompany.a2;

public interface IFoodie {
	public void setFoodConsumptionRate(int foodConsumptionRate);
	
}
